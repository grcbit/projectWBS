import
  * as jsGantt
  from './src/jsgantt';

declare var module: any;
module.exports = jsGantt.JSGantt;

export const JSGantt = jsGantt.JSGantt;
